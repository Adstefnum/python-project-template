# Python Project Template
Just a project template for proper python project structre for ease of manageability and automatic testing

# Add badge to view if tests are passing
![Tests](https://github.com/Adstefnum/python-project-template/actions/workflows/tests.yml/badge.svg)

# INstructions
- spin up a virtual env
- Install dev requirements locally and prod for production
- Install your whole project locally with  ``` pip install -e . ```

